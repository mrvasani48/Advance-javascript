let nums = [1, 2, 3, 5, 3, 2, 2, 4, 6] ;
let zonell=new Set(nums) ;
console.log(zonell) ;